package defineaninterfaceperson;

public interface Identifiable {
    String getId();
}
