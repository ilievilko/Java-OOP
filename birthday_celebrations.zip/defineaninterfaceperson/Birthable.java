package defineaninterfaceperson;

public interface Birthable {
    String getBirthDate();
}
